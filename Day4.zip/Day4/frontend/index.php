<?php
<?php
include 'pages/dbConnect.php';

$conn = connectDb();
$sql = "SELECT * FROM products ORDER BY created_at DESC LIMIT 8";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Trang chủ</title>
</head>
<body>
    <h1>Chào mừng đến với cửa hàng!</h1>
    <a href="pages/login.php">Đăng nhập</a> | <a href="pages/register.php">Đăng ký</a>
    <h2>Sản phẩm mới nhất</h2>
    <div>
        <?php while($row = $result->fetch_assoc()): ?>
            <div>
                <img src="<?php echo $row['image_url']; ?>" width="100">
                <h3><?php echo $row['name']; ?></h3>
                <p><?php echo $row['price']; ?> VNĐ</p>
            </div>
        <?php endwhile; ?>
    </div>
</body>
</html>