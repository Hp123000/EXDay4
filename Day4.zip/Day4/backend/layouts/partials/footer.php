<footer class="footer mt-auto py-3 bg-dark text-white"> 
    <div class="container-fluid"> 
<div class="row"> 
            <div class="col-md-2"></div> 
            <div class="col-md-10"> 
                <span>Copyright &copy; by <a 
href="https://localhost/DAY4">Demo Shop</a> - <script>document.write(new Date().getFullYear());</script>.</span> 
                <span class="text-muted">Simple shopping cart</span> 
            </div> 
        </div> 
    </div> 
</footer> 
