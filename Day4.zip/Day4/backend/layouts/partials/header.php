<nav class="navbar navbar-dark bg-dark shadow"> 
  <a class="navbar-brand col-sm-3 col-md-2 mr-0" href="/">DemoShop</a> 
  <ul class="navbar-nav px-3 mr-auto"> 
    <li class="nav-item text-nowrap"> 
      <a class="nav-link" href="/DAY4/backend/pages/dashboard.php">Dashboard</a> 
    </li> 
  </ul> 
</nav> 
