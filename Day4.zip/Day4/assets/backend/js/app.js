// Backend JS code 
